package com.example.thim4;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ThiM4ApplicationTests {

    @Test
    void contextLoads() {
    }

}
